# Tic-Tac-Toe-Web-Application
A simple yet engaging Tic Tac Toe web app built with HTML, CSS, and JavaScript. Enjoy a seamless gaming experience with an interactive interface and responsive design. Challenge a friend or play against the AI for endless fun and strategy

![Screenshot 2024-12-19 115007](https://github.com/user-attachments/assets/bea3d232-8586-4be9-ad74-c4b8c81db7ba)
![tic tac toe in ph](https://github.com/user-attachments/assets/9e2a8c53-efd9-48a8-9c07-ec75c7fb05df)
